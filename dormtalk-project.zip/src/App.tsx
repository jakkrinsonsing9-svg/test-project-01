import React, { useState, useEffect } from 'react';
import { ActiveTab, PostItem, UserProfile } from './types';
import { INITIAL_POSTS, INITIAL_USER } from './data/mockData';
import { applyThemeVariables, getInitialDarkMode } from './utils/theme';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { HomeFeed } from './components/HomeFeed';
import { CategoriesView } from './components/CategoriesView';
import { VerificationView } from './components/VerificationView';
import { LoginView } from './components/LoginView';
import { SettingsView } from './components/SettingsView';
import { NotificationsView } from './components/NotificationsView';
import { CreatePostModal } from './components/CreatePostModal';
import { ReportModal } from './components/ReportModal';
import {
  auth,
  testConnection,
  seedInitialPostsIfEmpty,
  subscribePosts,
  createPostInFirestore,
  toggleLikePostInFirestore,
  addCommentToFirestore,
  saveUserProfileToFirestore,
  getUserProfileFromFirestore,
} from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [darkMode, setDarkMode] = useState<boolean>(() => getInitialDarkMode());
  const [user, setUser] = useState<UserProfile>(() => ({
    ...INITIAL_USER,
    darkMode: getInitialDarkMode(),
  }));
  const [posts, setPosts] = useState<PostItem[]>(INITIAL_POSTS);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(2);
  const [firebaseConnected, setFirebaseConnected] = useState<boolean>(false);
  const [isFirebaseLoading, setIsFirebaseLoading] = useState<boolean>(true);

  // Sync theme variables and class on mount & changes
  useEffect(() => {
    applyThemeVariables(darkMode);
  }, [darkMode]);

  const handleToggleDarkMode = (explicitValue?: boolean) => {
    const next = explicitValue !== undefined ? explicitValue : !darkMode;
    setDarkMode(next);
    applyThemeVariables(next);
    setUser((prev) => {
      const updated = { ...prev, darkMode: next };
      if (auth.currentUser?.uid) {
        saveUserProfileToFirestore(auth.currentUser.uid, { darkMode: next });
      }
      return updated;
    });
    showToast(
      next
        ? 'เปิดใช้งานโหมดมืด (Dark Mode) • อัปเดต CSS Variables สำเร็จ'
        : 'สลับเป็นโหมดสว่าง (Light Mode) เรียบร้อยแล้ว'
    );
  };

  // Modals
  const [isCreatePostOpen, setIsCreatePostOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [reportTarget, setReportTarget] = useState<string>('');

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // 1. Firebase Initialization & Auth state listener
  useEffect(() => {
    let unsubscribePosts: (() => void) | null = null;

    async function initFirebase() {
      try {
        await testConnection();
        setFirebaseConnected(true);
        // Seed initial posts if the Firestore collection is fresh
        await seedInitialPostsIfEmpty();
      } catch (e) {
        console.warn('Firebase connection check:', e);
      } finally {
        setIsFirebaseLoading(false);
      }

      // Real-time Firestore subscription for posts & comments
      unsubscribePosts = subscribePosts(
        (updatedPosts) => {
          if (updatedPosts && updatedPosts.length > 0) {
            setPosts(updatedPosts);
          }
        },
        (error) => {
          console.warn('Firestore subscription notice:', error.message);
        }
      );
    }

    initFirebase();

    // Firebase Auth observer
    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await getUserProfileFromFirestore(fbUser.uid);
          if (profile) {
            setUser((prev) => ({
              ...prev,
              ...profile,
              uid: fbUser.uid,
              email: fbUser.email || undefined,
            }));
          } else {
            // New user, assign initial profile
            setUser((prev) => ({
              ...prev,
              uid: fbUser.uid,
              email: fbUser.email || undefined,
              studentIdMasked: fbUser.email ? fbUser.email.slice(0, 4) + '****' : prev.studentIdMasked,
            }));
          }
        } catch (e) {
          console.error('Error fetching user profile:', e);
        }
      } else {
        // Guest mode fallback
        setUser((prev) => ({
          ...INITIAL_USER,
          darkMode: prev.darkMode,
        }));
      }
    });

    return () => {
      if (unsubscribePosts) unsubscribePosts();
      unsubscribeAuth();
    };
  }, []);

  // Handlers for Posts, Likes, Comments in Cloud Firestore
  const handleLikePost = async (postId: string) => {
    const targetPost = posts.find((p) => p.id === postId);
    if (!targetPost) return;

    const currentLiked = Boolean(targetPost.isLiked);

    // Optimistic UI update
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const nextLiked = !currentLiked;
          return {
            ...post,
            isLiked: nextLiked,
            likes: nextLiked ? post.likes + 1 : Math.max(0, post.likes - 1),
          };
        }
        return post;
      })
    );

    // Persist to Cloud Firestore
    try {
      await toggleLikePostInFirestore(postId, currentLiked, auth.currentUser?.uid);
    } catch (err) {
      console.warn('Could not sync like to Firestore:', err);
    }
  };

  const handleAddComment = async (postId: string, commentText: string) => {
    const authorName = `สมาชิกนิรนาม ${user.anonymousTag}`;

    // Optimistic UI update
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const newComment = {
            id: `c-${Date.now()}`,
            author: authorName,
            timeAgo: 'เมื่อสักครู่',
            content: commentText,
            likes: 0,
            avatarColor: 'bg-[#e1e0ff]',
          };
          return {
            ...post,
            commentsCount: (post.commentsCount || post.comments.length) + 1,
            comments: [...post.comments, newComment],
          };
        }
        return post;
      })
    );
    showToast('เพิ่มความคิดเห็นเรียบร้อยแล้ว');

    // Persist to Cloud Firestore
    try {
      await addCommentToFirestore(postId, commentText, authorName, auth.currentUser?.uid);
    } catch (err) {
      console.warn('Could not sync comment to Firestore:', err);
    }
  };

  const handleCreatePost = async (newPostData: Partial<PostItem>) => {
    showToast('กำลังบันทึกโพสต์ลง Cloud Firestore...');
    setActiveTab('home');

    try {
      await createPostInFirestore(newPostData, user, auth.currentUser?.uid);
      showToast('สร้างโพสต์ใหม่สำเร็จบน Cloud Firestore ✨');
    } catch (err) {
      console.error('Failed to create post in Firestore:', err);
      // Fallback local addition if Firestore write fails
      const localPost: PostItem = {
        id: `post-${Date.now()}`,
        author: newPostData.author || `สมาชิกนิรนาม ${user.anonymousTag}`,
        authorBuilding: newPostData.authorBuilding || `${user.realBuilding} • ${user.floor}`,
        timeAgo: 'เมื่อสักครู่',
        category: newPostData.category || 'เรื่องหอพัก',
        categoryKey: newPostData.categoryKey || 'dorm',
        categoryEmoji: newPostData.categoryEmoji || '🏠',
        content: newPostData.content || '',
        imageUrl: newPostData.imageUrl,
        tags: newPostData.tags,
        likes: 1,
        isLiked: true,
        commentsCount: 0,
        comments: [],
      };
      setPosts([localPost, ...posts]);
      showToast('โพสต์ถูกสร้างในหน่วยความจำเรียบร้อยแล้ว');
    }
  };

  const handleUpdateUser = async (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
    if (auth.currentUser?.uid) {
      try {
        await saveUserProfileToFirestore(auth.currentUser.uid, updated);
        showToast('อัปเดตข้อมูลผู้ใช้ใน Cloud Firestore สำเร็จ');
      } catch (err) {
        console.warn('Failed to sync user profile:', err);
      }
    }
  };

  const handleOpenReportModal = (title: string) => {
    setReportTarget(title);
    setIsReportModalOpen(true);
  };

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--color-background)] text-[var(--color-on-surface)] selection:bg-[#e1e0ff] selection:text-[#4648d4] transition-colors duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-4 sm:right-8 z-50 animate-in slide-in-from-top duration-300">
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#111c2d] text-white shadow-xl text-xs font-medium border border-white/10">
            <span
              className="material-symbols-outlined text-[18px] text-[#6bff8f]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              check_circle
            </span>
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        unreadNotificationsCount={unreadNotificationsCount}
        onOpenCreatePost={() => setIsCreatePostOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />

      {/* Main View Router */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <HomeFeed
            posts={posts}
            user={user}
            activeCategoryFilter={activeCategoryFilter}
            setActiveCategoryFilter={setActiveCategoryFilter}
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
            onOpenReportModal={handleOpenReportModal}
            onLikePost={handleLikePost}
            onAddComment={handleAddComment}
            setActiveTab={setActiveTab}
            searchQuery={searchQuery}
          />
        )}

        {activeTab === 'categories' && (
          <CategoriesView
            posts={posts}
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
            onLikePost={handleLikePost}
            setActiveTab={setActiveTab}
            setActiveCategoryFilter={setActiveCategoryFilter}
            onOpenReportModal={handleOpenReportModal}
            initialSearchQuery={searchQuery}
          />
        )}

        {activeTab === 'verify' && (
          <VerificationView
            user={user}
            onUpdateUser={handleUpdateUser}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'login' && (
          <LoginView
            user={user}
            setActiveTab={setActiveTab}
            onLoginSuccess={(updatedProfile) => {
              if (updatedProfile) {
                setUser((prev) => ({ ...prev, ...updatedProfile }));
              }
              showToast('เข้าสู่ระบบสำเร็จผ่าน Firebase Auth');
            }}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            user={user}
            onUpdateUser={handleUpdateUser}
            setActiveTab={setActiveTab}
            onOpenReportModal={handleOpenReportModal}
            onShowToast={showToast}
            darkMode={darkMode}
            onToggleDarkMode={handleToggleDarkMode}
          />
        )}

        {activeTab === 'notifications' && (
          <NotificationsView
            setActiveTab={setActiveTab}
            onClearUnread={() => setUnreadNotificationsCount(0)}
            setActiveCategoryFilter={setActiveCategoryFilter}
          />
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCreatePost={() => setIsCreatePostOpen(true)}
        unreadCount={unreadNotificationsCount}
      />

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
        onSubmitPost={handleCreatePost}
        user={user}
      />

      {/* Content Report Modal */}
      <ReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onSuccess={showToast}
        targetTitle={reportTarget}
      />
    </div>
  );
}
